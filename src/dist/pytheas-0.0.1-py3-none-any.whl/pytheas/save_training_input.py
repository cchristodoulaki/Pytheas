
# Run using `python save_training_input.py`
# this code was created to generate two folders, 
# - CSV files named using the groundtruth_key from ground_truth_2k_canada
# - JSON files containing the annotations as persisted in ground_truth_2k_canada, 
# for the first 100 lines of their CSV files

from psycopg2 import connect
import json
from pprint import pprint
import os,shutil

con = connect(dbname='ground_truth_2k_canada', 
                user='christina', 
                host = 'localhost', 
                password='', 
                port = 5532) 
cur = con.cursor()
cur.execute("""SELECT groundtruth_key, original_path, annotations
                FROM ground_truth_2k_canada 
                """)
for db_tuple in cur:
    key = db_tuple[0]
    original_path = db_tuple[1]
    annotations = db_tuple[2]
    filepath = os.path.join('/home/christina/OPEN_DATA_CRAWL_2018',original_path)
    shutil.copy(filepath, f'../../data/Canada/csv_files/{key}.csv')

    with open(f'../../data/Canada/csv_annotations/{key}.json', 'w') as outfile:
        json.dump(annotations, outfile)

